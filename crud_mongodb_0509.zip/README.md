# CRUD MongoDB com Python e PyMongo

Este projeto oferece um exemplo de como realizar operações básicas de banco de dados (Criar, Ler, Atualizar, Deletar) em um MongoDB usando Python e a biblioteca `pymongo`. Ele foi feito para ser flexível, permitindo conexão com um MongoDB rodando localmente, em Docker ou em um serviço de nuvem.

## Como Funciona

O coração do projeto é o arquivo `main.py`. Ele contém uma classe que gerencia a conexão com o MongoDB e as funções para cada tipo de operação CRUD. A conexão pode ser configurada através de variáveis de ambiente, o que facilita a adaptação para diferentes ambientes (local, Docker, nuvem).

## Requisitos

- Python 3.x
- MongoDB (servidor)
- A biblioteca `pymongo` para Python

## Primeiros Passos

1.  **Instale o `pymongo`:** Se você ainda não tem, instale a biblioteca com pip:
    ```bash
    pip install pymongo
    ```

2.  **Configure a Conexão com o MongoDB:**
    O script tenta se conectar ao MongoDB usando as seguintes variáveis de ambiente:
    -   `MONGO_HOST` (padrão: `localhost`)
    -   `MONGO_PORT` (padrão: `27017`)
    -   `MONGO_DB` (padrão: `mydatabase`)
    -   `MONGO_COLLECTION` (padrão: `mycollection`)

    Você pode definir essas variáveis antes de executar o script para apontar para o seu servidor MongoDB (local, Docker ou nuvem). Por exemplo:
    ```bash
    export MONGO_HOST="seu_host_mongodb"
    export MONGO_PORT="27017"
    export MONGO_DB="seu_banco_de_dados"
    export MONGO_COLLECTION="sua_colecao"
    ```

    Para **Docker**, o `MONGO_HOST` pode ser o nome do serviço do MongoDB no seu `docker-compose.yml` (ex: `mongodb`).
    Para **nuvem** (como MongoDB Atlas), você pode precisar de uma URI de conexão completa. Nesse caso, adapte o código em `main.py` para usar `MongoClient("sua_uri_completa")`.

3.  **Execute o Código:**
    Depois de configurar a conexão, execute o script Python:
    ```bash
    python src/main.py
    ```
    O script vai rodar exemplos de operações CRUD e mostrar os resultados no terminal.

## Operações Suportadas

O `main.py` inclui funções para:

-   **Criar** novos documentos.
-   **Ler** documentos existentes (com ou sem filtros).
-   **Atualizar** documentos.
-   **Deletar** documentos.
-   **Conectar** e **desconectar** do banco de dados.

Este projeto serve como um ponto de partida simples para interagir com o MongoDB usando Python.

