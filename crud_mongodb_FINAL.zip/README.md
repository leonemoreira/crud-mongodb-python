# CRUD MongoDB com Python e PyMongo

Este projeto demonstra operações básicas de CRUD (Create, Read, Update, Delete) em um banco de dados MongoDB utilizando a biblioteca `pymongo` em Python. Ele é configurável para conexão local, via Docker ou com um serviço de nuvem.

## Estrutura do Projeto

```
crud_mongodb/
├── src/
│   └── main.py
├── venv/
└── README.md
```

## Requisitos

- Python 3.x
- MongoDB (local, Docker ou serviço de nuvem)
- `pymongo`

## Instalação

1. Clone este repositório:

   ```bash
   git clone <URL_DO_REPOSITORIO>
   cd crud_mongodb
   ```

2. Crie e ative um ambiente virtual (recomendado):

   ```bash
   python3.11 -m venv venv
   source venv/bin/activate
   ```

3. Instale as dependências:

   ```bash
   pip install pymongo
   ```

## Configuração do MongoDB

O script `main.py` tenta se conectar ao MongoDB usando variáveis de ambiente ou valores padrão. Você pode configurar a conexão de três maneiras:

### 1. Conexão Local

Certifique-se de que o MongoDB esteja rodando em sua máquina local na porta padrão (27017).

### 2. Conexão via Docker

Você pode rodar um contêiner MongoDB usando Docker. Exemplo de `docker-compose.yml`:

```yaml
version: '3.8'
services:
  mongodb:
    image: mongo:latest
    ports:
      - "27017:27017"
    environment:
      MONGO_INITDB_ROOT_USERNAME: admin
      MONGO_INITDB_ROOT_PASSWORD: password
    volumes:
      - mongodb_data:/data/db

volumes:
  mongodb_data:
```

Para iniciar o contêiner:

```bash
docker-compose up -d
```

No `main.py`, se você estiver rodando o script fora do contêiner Docker, o `MONGO_HOST` deve ser `localhost`. Se o script estiver rodando dentro de outro contêiner Docker na mesma rede, o `MONGO_HOST` pode ser o nome do serviço (ex: `mongodb`).

### 3. Conexão com Serviço de Nuvem (MongoDB Atlas, etc.)

Para conectar a um serviço de nuvem como MongoDB Atlas, você precisará da URI de conexão fornecida pelo seu provedor. Você pode passá-la diretamente no código ou via variável de ambiente.

Exemplo de URI (substitua pelos seus dados):

`mongodb+srv://<username>:<password>@<cluster-address>/<database-name>?retryWrites=true&w=majority`

Você pode definir as variáveis de ambiente antes de executar o script:

```bash
export MONGO_HOST="your_cloud_mongodb_uri"
export MONGO_PORT="27017" # Ou a porta do seu serviço de nuvem
export MONGO_DB="your_database_name"
export MONGO_COLLECTION="your_collection_name"
```

## Como Executar

1. Ative o ambiente virtual (se ainda não estiver ativo):

   ```bash
   source venv/bin/activate
   ```

2. Execute o script Python:

   ```bash
   python src/main.py
   ```

O script executará as operações CRUD de exemplo e imprimirá os resultados no console.

## Operações CRUD Implementadas

O arquivo `main.py` contém a classe `MongoDBManager` com os seguintes métodos:

- `connect()`: Estabelece a conexão com o MongoDB.
- `create_document(document)`: Insere um novo documento na coleção.
- `read_documents(query=None)`: Lê documentos da coleção. Se `query` for fornecido, filtra os resultados.
- `update_document(query, new_values)`: Atualiza um documento existente com novos valores.
- `delete_document(query)`: Deleta um documento da coleção.
- `close_connection()`: Fecha a conexão com o MongoDB.



