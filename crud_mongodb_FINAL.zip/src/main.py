
import os
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure

class MongoDBManager:
    def __init__(self, host='localhost', port=27017, db_name='testdb', collection_name='testcollection'):
        self.host = host
        self.port = port
        self.db_name = db_name
        self.collection_name = collection_name
        self.client = None
        self.db = None
        self.collection = None

    def connect(self):
        try:
            self.client = MongoClient(self.host, self.port)
            self.client.admin.command('ping')
            self.db = self.client[self.db_name]
            self.collection = self.db[self.collection_name]
            print(f"Conectado ao MongoDB em {self.host}:{self.port}")
        except ConnectionFailure as e:
            print(f"Falha na conexão com o MongoDB: {e}")
            self.client = None
            self.db = None
            self.collection = None

    def create_document(self, document):
        if not self.collection:
            print("Não conectado ao MongoDB.")
            return None
        try:
            result = self.collection.insert_one(document)
            print(f"Documento criado com ID: {result.inserted_id}")
            return result.inserted_id
        except Exception as e:
            print(f"Erro ao criar documento: {e}")
            return None

    def read_documents(self, query=None):
        if not self.collection:
            print("Não conectado ao MongoDB.")
            return []
        try:
            documents = list(self.collection.find(query if query else {}))
            print(f"Documentos encontrados: {len(documents)}")
            return documents
        except Exception as e:
            print(f"Erro ao ler documentos: {e}")
            return []

    def update_document(self, query, new_values):
        if not self.collection:
            print("Não conectado ao MongoDB.")
            return None
        try:
            result = self.collection.update_one(query, {'$set': new_values})
            print(f"Documentos atualizados: {result.modified_count}")
            return result.modified_count
        except Exception as e:
            print(f"Erro ao atualizar documento: {e}")
            return None

    def delete_document(self, query):
        if not self.collection:
            print("Não conectado ao MongoDB.")
            return None
        try:
            result = self.collection.delete_one(query)
            print(f"Documentos deletados: {result.deleted_count}")
            return result.deleted_count
        except Exception as e:
            print(f"Erro ao deletar documento: {e}")
            return None

    def close_connection(self):
        if self.client:
            self.client.close()
            print("Conexão com MongoDB fechada.")

if __name__ == "__main__":
    # Configuração de conexão (pode ser alterada via variáveis de ambiente ou diretamente aqui)
    # Exemplo para Docker/Local: host='localhost', port=27017
    # Exemplo para Nuvem: host='your_cloud_mongodb_uri', port=27017 (ou porta padrão da nuvem)

    # Para Docker, o host pode ser o nome do serviço no docker-compose, ex: 'mongodb'
    # Para nuvem, a URI completa pode ser passada, ex: MongoClient('mongodb+srv://user:pass@host/db?retryWrites=true&w=majority')

    MONGO_HOST = os.getenv('MONGO_HOST', 'localhost')
    MONGO_PORT = int(os.getenv('MONGO_PORT', 27017))
    MONGO_DB = os.getenv('MONGO_DB', 'mydatabase')
    MONGO_COLLECTION = os.getenv('MONGO_COLLECTION', 'mycollection')

    db_manager = MongoDBManager(host=MONGO_HOST, port=MONGO_PORT, db_name=MONGO_DB, collection_name=MONGO_COLLECTION)
    db_manager.connect()

    if db_manager.collection:
        # Exemplo de uso das operações CRUD
        print("\n--- Criando Documento ---")
        new_doc_id = db_manager.create_document({"name": "Teste", "value": 10})
        db_manager.create_document({"name": "Outro Teste", "value": 20})

        print("\n--- Lendo Documentos ---")
        all_docs = db_manager.read_documents()
        for doc in all_docs:
            print(doc)

        print("\n--- Atualizando Documento ---")
        db_manager.update_document({"name": "Teste"}, {"value": 15, "status": "updated"})
        updated_doc = db_manager.read_documents({"name": "Teste"})
        for doc in updated_doc:
            print(doc)

        print("\n--- Deletando Documento ---")
        db_manager.delete_document({"name": "Outro Teste"})
        remaining_docs = db_manager.read_documents()
        for doc in remaining_docs:
            print(doc)

    db_manager.close_connection()


